<?php

/**
* Smarty method isCompileCheck
* 
* is compile checking
* 
* @package Smarty
* @subpackage SmartyMethod
* @author Uwe Tews 
*/

/**
* is compile checking
*/
function isCompileCheck($smarty)
{
    return $smarty->compile_check;
} 

?>
