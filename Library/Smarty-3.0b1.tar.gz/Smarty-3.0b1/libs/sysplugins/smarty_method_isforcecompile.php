<?php

/**
* Smarty method isForceCompile
* 
* is forced compiling
* 
* @package Smarty
* @subpackage SmartyMethod
* @author Uwe Tews 
*/

/**
* 
* is forced compiling
*/
function isForceCompile($smarty)
    {
        return $smarty->force_compile;
    } 


?>
