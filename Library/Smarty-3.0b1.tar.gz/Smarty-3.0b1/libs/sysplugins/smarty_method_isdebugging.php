<?php

/**
* Smarty method isDebugging
* 
* is debugging
* 
* @package Smarty
* @subpackage SmartyMethod
* @author Uwe Tews 
*/

/**
* is debugging
*/
function isDebugging($smarty)
{
    return $smarty->debugging;
} 

?>
