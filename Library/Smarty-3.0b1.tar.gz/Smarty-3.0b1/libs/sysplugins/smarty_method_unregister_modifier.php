<?php

/**
* Smarty method Unregister_Modifier
* 
* Unregister a Smarty modifier plugin
* 
* @package Smarty
* @subpackage SmartyMethod
* @author Uwe Tews 
*/

/**
* Unregister a Smarty modifier plugin
*/

/**
* Unregisters modifier
* 
* @param string $modifier name of template modifier
*/
function unregister_modifier($smarty, $modifier)
{
    if (isset($smarty->registered_plugins[$modifier]) && $smarty->registered_plugins[$modifier][0] == 'modifier') {
        unset($smarty->registered_plugins[$modifier]);
    } 
} 

?>
