<?php

/**
* Smarty method getTemplateDir
* 
* Returns template directory
* 
* @package Smarty
* @subpackage SmartyMethod
* @author Uwe Tews 
*/

/**
* Returns template directory
*/

/**
* Returns template directory
* 
* @return array template folders
*/
function getTemplateDir($smarty)
{
    return $smarty->template_dir;
} 

?>
