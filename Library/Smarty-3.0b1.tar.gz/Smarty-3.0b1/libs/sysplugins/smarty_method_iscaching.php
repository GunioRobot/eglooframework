<?php

/**
* Smarty method isCaching
* 
* is caching
* 
* @package Smarty
* @subpackage SmartyMethod
* @author Uwe Tews 
*/

/**
* is caching
*/
function isCaching($smarty)
{
    return $smarty->caching;
} 

?>
