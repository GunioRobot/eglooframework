<?php

/**
* Smarty method isCacheModifyCheck
* 
* is cache modify check
* 
* @package Smarty
* @subpackage SmartyMethod
* @author Uwe Tews 
*/

/**
* is cache modify check
*/
function isCacheModifyCheck()
{
    return $smarty->cache_modified_check;
} 

?>
